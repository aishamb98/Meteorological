from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import  Response
from rest_framework.views import APIView
from .serializers import RegistrationSerializer, PasswordChangeSerializer
from rest_framework_simplejwt.tokens import RefreshToken

def get_tokens_for_user(user):

   
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'accessToken': str(refresh.access_token),
    }


class RegistrationView(APIView):
    permission_classes = []
    def post(self, request):
        serializer = RegistrationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            user = User.objects.get(username=serializer.data["username"])
            auth_data = get_tokens_for_user(user)
            return Response( {"user": user.username , **auth_data} , status=status.HTTP_201_CREATED) # It received the data.
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST) # Error, it did not receive data.



      
class LoginView(APIView):
    permission_classes = []
    def post(self, request):
        if 'username' not in request.data or 'password' not in request.data:
            return Response({'msg': 'Credentials missing'}, status=status.HTTP_400_BAD_REQUEST) # Error, it did not receive data.
        username = request.data['username']
        password = request.data['password']
       
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            auth_data = get_tokens_for_user(request.user)
            return Response({'msg': 'Login Success' ,  **auth_data, "user": user.username}, status=status.HTTP_200_OK) # It received the data.
        return Response({'msg': 'Invalid Credentials'}, status=status.HTTP_401_UNAUTHORIZED) # Error, it did not receive data.

      
class LogoutView(APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        logout(request)
        return Response({'msg': 'Successfully Logged out'}, status=status.HTTP_200_OK)


      
class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated, ]
    def post(self, request):
        serializer = PasswordChangeSerializer(context={'request': request}, data=request.data)
        serializer.is_valid(raise_exception=True)
        request.user.set_password(serializer.validated_data['new_password'])
        request.user.save()
        return Response(status=status.HTTP_204_NO_CONTENT) # It received the data.