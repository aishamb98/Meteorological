import codecs # I used it to convert Arabic speech into understandable speech
import requests
import json


# It opens and reads the JSON file
data = codecs.open('cities.json', encoding="utf-8")
data = json.load(data)
url = "http://127.0.0.1:8000/api/city/"

for city in data:
    c= city["center"]
    city["center"] = f'{c}'
    requests.post(url, city)
print("OK")