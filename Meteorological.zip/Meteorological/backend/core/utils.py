import meteomatics.api as api
import meteomatics.binary_parser as p
import datetime as dt

import DjangoWeather.settings as stng

# It receives data from the Meteomatics API server

username = stng.USERNAME
password = stng.PASSWORD

def get_city_paginate(cords):
    startdate = dt.datetime.utcnow()
    enddate = startdate+ dt.timedelta(days=1)
    interval = dt.timedelta(hours=24)
    parameters = ['t_max_2m_24h:C', "t_min_2m_24h:C","weather_symbol_24h:idx"]
    try:
        df = api.query_time_series(cords, startdate, enddate, interval, parameters, username, password)
        return df.to_json(orient = 'table')
    except:
        return "error"
        
   

def get_city(cords):
    startdate = dt.datetime.utcnow().replace(hour=1,minute=0,second=0,microsecond=0)
    enddate = startdate+ dt.timedelta(days=1)
    interval = dt.timedelta(hours=1)
    parameters = ['t_2m:C', "relative_humidity_2m:p","precip_1h:mm", "wind_speed_10m:ms","wind_dir_10m:d", "weather_symbol_1h:idx"]
    try:
        df = api.query_time_series(cords, startdate, enddate, interval, parameters, username, password)
        return df.to_json(orient = 'table')
    except:
        return "error"
        
   

