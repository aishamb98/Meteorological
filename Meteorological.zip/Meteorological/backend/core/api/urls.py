from rest_framework.routers import DefaultRouter
from .views import cityview


router = DefaultRouter()
router.register('city', cityview)
urlpatterns = router.urls