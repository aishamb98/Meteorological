from core.models import City
from .serializers import CitySerializer
from rest_framework.viewsets import ModelViewSet
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import AllowAny
from rest_framework import filters


class cityview(ModelViewSet):
    search_fields = ['name_ar', 'name_en']
    filter_backends = (filters.SearchFilter,)
    queryset = City.objects.all() # Data that turns into an API
    serializer_class = CitySerializer # Converts data into a table
