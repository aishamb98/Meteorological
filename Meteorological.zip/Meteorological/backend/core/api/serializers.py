from rest_framework.serializers import ModelSerializer
from core.models import City

# Converts the data city to JSON data

class CitySerializer(ModelSerializer):
    class Meta:
        model = City
        fields = '__all__'