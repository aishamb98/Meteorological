from django.db import models

# it imports data from the JSON file >> cities.json


class City(models.Model):
    city_id = models.PositiveIntegerField()
    region_id = models.PositiveIntegerField()
    name_ar = models.CharField(max_length=50)
    name_en = models.CharField(max_length=50)
    center = models.JSONField()

    def __str__(self):
        return self.name_ar