from django.shortcuts import render
from django.http import JsonResponse
from .models import City
from .utils import get_city,get_city_paginate
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth.decorators import login_required

import json

@login_required(login_url="/user/login/")
def home(request):
    citis =  City.objects.all()[:]
    city = City.objects.get(id=2)
    x=[tuple(city.center)]
    c =get_city(x)
    return render(request, "home.html",{"cities" : citis})


def getWeather(request, city_id):
    # It filters cities and makes them a city unit
    city = City.objects.get(city_id=city_id)
    cords = [tuple(city.center)]
    data = json.loads(get_city(cords)) # It converts it into JSON data
    return JsonResponse(data)

def getWeatherPaginate(request, city_id):
    city = City.objects.get(city_id=city_id)
    cords = [tuple(city.center)]
    data = json.loads(get_city_paginate(cords))
    print(get_city_paginate(cords))
    return JsonResponse(data)
    
def getPaginate(request, lat,lot):
    cords = [(lat,lot)]
    data = json.loads(get_city_paginate(cords))
    return JsonResponse(data)


    
    
    