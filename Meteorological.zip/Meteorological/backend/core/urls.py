from django.urls import path
from .views import home,getWeather,getWeatherPaginate,getPaginate
app_name = 'core'

urlpatterns = [
    path("", home , name="home"),
    path("display/<int:city_id>/", getWeather),
    path("paginate/<int:city_id>/", getWeatherPaginate),
    path("getformy/<str:lat>/<str:lot>/", getPaginate),
]

