import React,{Component, useEffect, useState} from "react";
import { useActionData, useParams } from "react-router-dom";
import Navar from "./Navar";






function Weather() {
    const {city_id} = useParams()
    
    const [city, setCity] = useState([])
    const [items, setItems]= useState([''])
    
    
    const url = `http://127.0.0.1:8000/display/${city_id}/`
    const cityurl = `http://127.0.0.1:8000/api/city/${city_id}/`
    useEffect(()=>{
        componentDidMount()
      }, [city_id])


    const componentDidMount = async() =>{
            fetch(url)
            .then((response) => response.json())
            .then((data) => {
                setItems(data.data)
            })
            fetch(cityurl)
            .then((response) => response.json())
            .then((data) => {
                setCity(data)
                
            })
    }
    

       
   
        return (
        <>     
        <Navar/>  
            <div className = "Head text-center border rounded my-2 py-3">
                <div className="h3">{city["name_en"]} - {city["name_ar"]}</div>
            </div>
            <div className="container">
            <table className="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">الساعة</th>
                            <th scope="col">درجة الحرارة الادنى</th>
                            <th scope="col">درجة الحرارة الاعلى</th>
                            <th scope="col">حالة الطقس</th>
                            <th scope="col">اتجاه الرياح</th>
                            <th scope="col">سرعة الرياح</th>
                        </tr>
                    </thead>
                    <tbody>
                        {items.map(el => 
                            <tr>
                                <th>{el["validdate"]}</th>
                                <td>{el["lat"]}</td>
                                <td>{el["lon"]}</td>
                                <td>
                                    <img src={ "http://127.0.0.1:8000/media/img/"+ el["weather_symbol_1h:idx"]+".png"} class="img-fluid rounded-top" className="icon" alt=""/>
                                    </td>
                                <td>{el["wind_dir_10m:d"]}</td>
                                <td>{el["wind_speed_10m:ms"]}</td>
                            </tr>
                            )}
                    </tbody>
            </table>
            </div>
            </>

        
        )
    
   
}
    
export default Weather;
