import React, {  useEffect } from 'react';
import { useState } from 'react';
import { Link,Router } from 'react-router-dom';

const url = "http://127.0.0.1:8000/"



function Pagination(props) {
  const [data, setData] = useState([])
  const [city, setCity] = useState([])
  const [name, setName] = useState(14)
  const [latitude, setlatitude] = useState()
  const [longitude, setlongitude] = useState()

  function geoFindMe() {

    function success(position) {
        setlatitude(position.coords.latitude);
      setlongitude(position.coords.longitude);
  
      
    }
  
    function error() {
   
    }
  
    if (!navigator.geolocation) {
    
    } else {
  
      navigator.geolocation.getCurrentPosition(success, error);
    }
  
  }
  

  
useEffect(()=> {
    componentDidMount()
},[latitude])
 
const componentDidMount = async() =>{

    geoFindMe();

    fetch(`http://127.0.0.1:8000/getformy/${latitude}/${longitude}/`)
    .then((response) => response.json())
    .then((data) => {
        setData(data["data"][0])
    })
    
}
  
  return (
    <>
    
    
    <ul className="navbar-nav flex-row flex-wrap ms-md-auto gap-5">
   

    <div class="carousel-inner">
                <div class="carousel-item active">
                  <div class="d-flex justify-content-between mb-4 ">
                  <li className="nav-item col-6 my-auto col-md-auto">
                    <div>
                      <h2 class="display-5"><strong>{(data["t_max_2m_24h:C"] + data["t_min_2m_24h:C"]) / 2}</strong></h2>
                      <p class="text-muted mb-0">{data["t_min_2m_24h:C"]}        -        {data["t_max_2m_24h:C"]}</p>
                    </div>
                    </li>
                    <li className="nav-item col-6 my-auto col-md-auto"></li>
                    <div>
                      <img src={ "http://127.0.0.1:8000/media/img/"+ data["weather_symbol_24h:idx"]+".png"}
                        width="80px"/>
                    </div>
                  </div>
                </div>
              </div>
        
    </ul>
   
    </>
  )
}

export default Pagination;