import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';



const useStyles = makeStyles((theme) => ({
 
}));

async function loginUser(credentials) {
  return fetch('http://127.0.0.1:8000/api/user/login/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(credentials)
  })
    .then(data =>{
      if (data.status ==401){
        return
      }
       else {
        return data.json()
       }
    })
 }

export default function Signin() {
  const classes = useStyles();
  const [username, setUserName] = useState();
  const [password, setPassword] = useState();

  const handleSubmit = async e => {
    e.preventDefault();
    await loginUser({
      username,
      password
    })
      
      .then((response) => {
        localStorage.setItem('accessToken', response['accessToken']);
        localStorage.setItem('user', response['user']);
        window.location.href = "/";
      }).catch(error =>{
    
      alert("Failed", error.msg, "error")})
    
  }
  if(localStorage.getItem("user")){
    window.location.href = "/";
  }
  return (
  
    <div container className={"container m-5 text-center"}>
          <Typography component="h4" variant="h5">
            Sign in
          </Typography>
          <form className={"form login w-25 text-center m-auto"} noValidate onSubmit={handleSubmit}>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="username"
              name="username"
              label="username"
              onChange={e => setUserName(e.target.value)}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="password"
              name="password"
              label="Password"
              type="password"
              onChange={e => setPassword(e.target.value)}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              className={classes.submit}
            >
              Sign In
            </Button>
          </form>
        
      </div>
  );
}