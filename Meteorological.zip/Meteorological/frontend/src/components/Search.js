import React, {  useEffect } from 'react';
import { useState } from 'react';
import { Link,Router } from 'react-router-dom';

const url = "http://127.0.0.1:8000/api"

function Search(props) {
  const [data, setData] = useState([])
  const [name, setName] = useState([])
 

  useEffect(()=>{
    fetchData()
  }, [name])
  
  const fetchData= async() => {
    const endboint = `${url}/city/?search=${name}`
    
    try {
      const response = await fetch (endboint,{
        method:"GET"

      })
      const data = await response.json()
      setData(data)
    }
      catch (e){
        console.log(e)
      }
  }
  return (
    <>
    
    <div>
      <input className="form-control mr-sm-2" type="search"  aria-labelledby="navbarDropdown" placeholder="Search" aria-label="Search"
      value={name}
      onChange={(e) => {
        setName(e.target.value);
      if (e.target.value !== ""){
          
          var l = document.querySelectorAll("#ul").length - 1;
          document.querySelectorAll("#ul")[l].classList.remove("d-none");
      }
      else{
        var l = document.querySelectorAll("#ul").length - 1;
        document.querySelectorAll("#ul")[l].classList.add("d-none");
      }
    }}
      />

      <div className="list-group position-absolute d-none mr-sm-2" id="ul">
        {       
           data.map(el => <Link className="list-group-item list-group-item-action w-100" key={el.id} id={el.city_id} to={`/${el.city_id}`}>{el.name_ar}</Link> )
           }
      </div>
      </div>
    </>
  )
}

export default Search;