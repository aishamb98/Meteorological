import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';


const useStyles = makeStyles((theme) => ({
 
}));

async function loginUser(credentials) {
  return fetch('http://127.0.0.1:8000/api/user/register/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(credentials)
  })
    .then(data => data.json())
 }

export default function Register() {
  const classes = useStyles();
  const [username, setUserName] = useState();
  const [password, setPassword] = useState();
  const [password2, setPassword2] = useState();

  const handleSubmit = async e => {
    e.preventDefault();
    await loginUser({
      username,
      password,
      password2
    })
      .then((response) => {
        localStorage.setItem('accessToken', response['accessToken']);
        localStorage.setItem('user', response['user']);
        window.location.href = "/";
      }).catch(error =>{
    
      alert("Failed", error.msg, "error")})
    
  }
  if(localStorage.getItem("user")){
    window.location.href = "/";
  }
  return (
    <div container className={"container m-5 text-center"}>
          <Typography component="h4" variant="h5">
           Register
          </Typography>
          <form className={"form login w-25 text-center m-auto"} noValidate onSubmit={handleSubmit}>
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="username"
              name="username"
              label="username"
              onChange={e => setUserName(e.target.value)}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="password"
              name="password"
              label="Password"
              type="password"
              onChange={e => setPassword(e.target.value)}
            />
            <TextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              id="password2"
              name="password2"
              label="confirm Password"
              type="password"
              onChange={e => setPassword2(e.target.value)}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              className={classes.submit}
            >
             Register
            </Button>
          </form>
        
      </div>
  );
}