import React, { Component, useCallback, useEffect, useReducer, useState } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'
import Weather from './components/Weather';
import Navar from './components/Navar';
import { BrowserRouter } from 'react-router-dom';
import Search from './components/Search';


function App() {

  const [city_id, setCity] = useState(2)
  const CityChange = (event) =>{
    setCity(event.target.id);
    console.log(localStorage.getItem("user"))
    
  }
  return (
  <>

  <Navar/>
  <>
      <div className="container mt-5 text-center py-3 border border-dark rounded" >
      <h1>Welcome To DjangoWeather</h1>
        <div className="p-2 m-5">
        <h3>Search your City</h3>
          <Search/>
          </div>
      </div>
      </>
  </>
  );
  }


export default App;
