import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Weather from './components/Weather';
import * as serviceWorkerRegistration from './serviceWorkerRegistration';
import reportWebVitals from './reportWebVitals';
import App from './App';
import Navar from './components/Navar';
import Logout from './components/Logout';
import {
  Routes,
  BrowserRouter,
  createBrowserRouter,
  RouterProvider,
  Route,
} from "react-router-dom";
import Signin from './components/Signin';
import Register from './components/Register';

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
  },
  {
    path: "/logout",
    element: <Logout />,
  },
      {
        path: "/:city_id",
        element: <Weather />,
        
      },
      {
        path: "/login",
        element: <Signin />,
        
      },
      {
        path: "/register",
        element: <Register/>,
        
      },
    
  
]);


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);




serviceWorkerRegistration.register();
reportWebVitals();
